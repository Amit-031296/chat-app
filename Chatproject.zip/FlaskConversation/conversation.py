from flask import Flask, request,session,abort,render_template,redirect,url_for
from datetime import timedelta
from flask_sqlalchemy import SQLAlchemy
from validate_email import validate_email
import phonenumbers
from phonenumbers import carrier
from phonenumbers.phonenumberutil import number_type



app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.sqlite3'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = "random string"
app.config['PERMANENT_SESSION_LIFETIME'] =  timedelta(minutes=10)



db = SQLAlchemy(app)
class users(db.Model):
   id = db.Column('user_id', db.Integer, primary_key = True)
   name = db.Column(db.String(50))
   email = db.Column(db.String(50))
   addr = db.Column(db.String(200))
   mobile_no = db.Column(db.String(20))
   msg = db.Column(db.String(200))

def __init__(self, name, email, addr,mobile_no, msg, status):
   self.name = name
   self.email = email
   self.addr = addr
   self.mobile_no = mobile_no
   self.msg = msg

db.create_all()

@app.route('/')
def home():
    message = "Please Enter the Mobile Number"
    return render_template('welcome.html', message=message)


@app.route('/conversation', methods=['POST','GET'])
def conversation():
    try:
        if request.method == "POST":
            session.permanent = True
            session['mobile_no'] = request.form['mobile']
            print("Mobile Number entered was ==>",session['mobile_no'])
            if "mobile_no" in session:
                number = session["mobile_no"]
                try:
                    register_no = carrier._is_mobile(number_type(phonenumbers.parse(number)))
                    if register_no:
                        item=db.session.query(users.id).filter_by(mobile_no=number).scalar()
                        if item is None:
                            session["count"] = 1
                            return '''
	
                    <form action = "conversation1" method = "post">
                        <h1>Hii</h1>
                        <label for="name">what is your name??</label><br><br>
                        <input type="text" id="fname" name="fname" required><br><br>
                        <input type="submit" value="Submit">
                    </form>	
                    '''
                        else:
                            return "You are already registered!"
                    return "Enter valid contact Number!!"
                except:
                    return "Please enter valid mobile number with country code eg: +919892601879 or +49 176 1234 5678 "
            else:
                abort(400)
        else:
            session.clear()
            return "Something went wrong.Your session expire. Please try again!!"
    except Exception as e:
        print(e)
        session.clear()
        return "Something went wrong.Your session expire. Please try again!!"

@app.route('/conversation1', methods=['POST','GET'])
def conversation1():
    try:
        if request.method == "POST":
            if session["count"] == 1:
                session["Name"] = request.form['fname']
                session["count"] = 2
                return '''
	
                    <form action = "conversation2" method = "post">
                        <label for="name">what is your email??</label><br><br>
                        <input type="email" id="email" name="email" required><br><br>
                        <input type="submit" value="Submit">
                    </form>	
                    '''
            else:
                return "Please Enter valid name"
    except Exception as e:
        print(e)
        session.clear()
        return "Something went wrong.Your session expire. Please try again!!"


@app.route('/conversation2', methods=['POST','GET'])
def conversation2():
    try:
        if request.method == "POST":
            if session["count"] == 2:
                session["Email"] = request.form['email']
                session["count"] = 3
                return '''
	
                    <form action = "conversation3" method = "post">
                        <label for="name">what is your Address??</label><br><br>
                        <input type="text" id="address" name="address" required><br><br>
                        <input type="submit" value="Submit">
                    </form>	
                    '''
            else:
                return "Please Enter valid email"
    except Exception as e:
        print(e)
        session.clear()
        return "Something went wrong.Your session expire. Please try again!!"

@app.route('/conversation3', methods=['POST','GET'])
def conversation3():
    try:
        if request.method == "POST":
            if session["count"] == 3:
                session["Address"] = request.form['address']
                session["count"] = 4
                return '''
                    <form action = "conversation4" method = "post">
                        <label for="name">Enquire About??</label><br><br>
                        <input type="text" id="enquiry" name="enquiry" required><br><br>
                        <input type="submit" value="Submit">
                    </form>	
                    '''
            else:
                return "Please Enter valid email"
    except Exception as e:
        print(e)
        session.clear()
        return "Something went wrong.Your session expire. Please try again!!"

@app.route('/conversation4', methods=['POST','GET'])
def conversation4():
    try:
        if request.method == "POST":
            if session["count"] == 4:
                session["Enquire"] = request.form['enquiry']
                print("session dictionary ==>",session)
                user = users(mobile_no=session["mobile_no"], name=session["Name"],
                                            email=session["Email"],addr=session["Address"],
                                            msg=session["Enquire"])
                db.session.add(user)
                db.session.commit()
                session.clear()
                return "Thank You"
    except Exception as e:
        print(e)
        session.clear()
        return "Something went wrong.Your session expire. Please try again!!"

@app.route('/logout')
def logout():
   return redirect(url_for('/'))


if __name__ == '__main__':
    # app.run(port=5000, debug=True, host='0.0.0.0')
    app.run(debug=True)