from flask import Flask, request,session , abort
from datetime import timedelta
from flask_sqlalchemy import SQLAlchemy
from validate_email import validate_email
import phonenumbers
from phonenumbers import carrier
from phonenumbers.phonenumberutil import number_type



app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///usersdb.sqlite3'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = "random string"
app.config['PERMANENT_SESSION_LIFETIME'] =  timedelta(minutes=10)



db = SQLAlchemy(app)
class usersdb(db.Model):
   id = db.Column('user_id', db.Integer, primary_key = True)
   name = db.Column(db.String(50))
   email = db.Column(db.String(50))
   addr = db.Column(db.String(200))
   mobile_no = db.Column(db.String(20))
   msg = db.Column(db.String(200))

def __init__(self, name, email, addr,mobile_no, msg, status):
   self.name = name
   self.email = email
   self.addr = addr
   self.mobile_no = mobile_no
   self.msg = msg

db.create_all()


@app.route('/conversation', methods=['POST','GET'])
def conversation():

    try:
        session.permanent = True
        if not "mobile_no" in session:
            event = request.json
            if event:
                number = event["mobile_no"]
                try:
                    register_no = carrier._is_mobile(number_type(phonenumbers.parse(number)))
                    if register_no:
                        item=db.session.query(usersdb.id).filter_by(mobile_no=request.json["mobile_no"]).scalar()
                        if item is None:
                            session["mobile_no"] = event["mobile_no"]
                            session["count"] = 1
                            return "what is your name??"
                        else:
                            return "You are already registered!"
                    return "Enter valid contact Number!!"
                except:
                    return "Please enter valid mobile number with country code eg: +919892601879 or +49 176 1234 5678 "
            else:
                abort(400)

        else:
            string_event = request.data.decode('utf-8')
            if session["count"] == 1:
                if string_event.replace(" ", "").isalpha():
                    session["Name"] = string_event
                    session["count"] = 2
                    return "what is your email??"
                else:
                    return "Please Enter valid name"
            elif session["count"] == 2:
                # if validate_email(email_address=string_event, check_regex=True):
                session["Email"] = string_event
                session["count"] = 3
                return "what is your Address??"
                # else:
                #     return "Please Enter valid email"
            elif session["count"] == 3:
                session["Address"] = string_event
                session["count"] = 4
                return "Enquire About??"
            elif session["count"] == 4:
                session["Enquire"] = string_event
                user = usersdb(mobile_no=session["mobile_no"], name=session["Name"],
                                   email=session["Email"],addr=session["Address"],
                                   msg=session["Enquire"])
                db.session.add(user)
                db.session.commit()
                session.clear()
                return "Thank You"
    except Exception as e:
        print(e)
        session.clear()
        return "Something went wrong.Your session expire. Please try again!!"


if __name__ == '__main__':
    app.run(port=5000, debug=True, host='0.0.0.0')